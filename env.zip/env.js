const PLATFROM_URL='https://app.linkdominator.com'
const LINKEDIN_URL='https://www.linkedin.com'
const VOYAGER_API=LINKEDIN_URL+'/voyager/api'