
$('.messageTargetUserAction').click(async function() {
    try {
        console.log('🔍 Starting Message Targeted Users process...');
        
        // Clear previous status
        $('#displayMessageTargetStatus').empty();
        $('#mtu-error-notice').empty();

        // Get form values
        const form = {
            startPosition: $('#mtu-startPosition'),
            total: $('#mtu-totalMessageConnect'),
            delay: $('#mtu-delayTime'),
            message: $('#mtu-personalMessage'),
            audience: $('#mtu-selectAudience'),
            searchTerm: $('#mtu-search-term')
        };

        // Validate fields
        const errors = [];
        
        // Required fields
        if (!form.total.val()) errors.push('Total messages is required');
        if (!form.delay.val()) errors.push('Delay is required');
        if (!form.message.val()) errors.push('Message is required');
        
        // Delay minimum
        if (form.delay.val() && parseInt(form.delay.val()) < 30) {
            errors.push('Delay must be at least 30 seconds');
        }

        // Show errors if any
        if (errors.length > 0) {
            console.log('❌ Validation errors:', errors);
            $('#mtu-error-notice').html(`
                <div class="alert alert-danger">
                    <ul style="margin-bottom: 0;">
                        ${errors.map(error => `<li>${error}</li>`).join('')}
                    </ul>
                </div>
            `);
            return;
        }

        // Clear any previous errors
        $('#mtu-error-notice').html('');

        // Disable send button
        $(this).attr('disabled', true);
        
        // Get excluded connection IDs
        const mtuConnectionIds = [];
        $('#mtu-selectedExConnect li').each(function() {
            const connectionId = $(this).data('connectionid');
            if (connectionId) mtuConnectionIds.push(connectionId);
        });

        // Build query parameters
        let queryParams = '';

        // Check filter selections
        if ($('#mtu-selectedConnectOf li').length > 0) {
            queryParams += setFIlterQueryParams('#mtu-selectedConnectOf', 'connectionid', 'connectionOf');
        }
        if ($('#mtu-selectedLocation li').length > 0) {
            queryParams += setFIlterQueryParams('#mtu-selectedLocation', 'regionid', 'geoUrn');
        }
        if ($('#mtu-selectedSchool li').length > 0) {
            queryParams += setFIlterQueryParams('#mtu-selectedSchool', 'schoolid', 'schoolFilter');
        }
        if ($('#mtu-selectedCurrComp li').length > 0) {
            queryParams += setFIlterQueryParams('#mtu-selectedCurrComp', 'currcompid', 'currentCompany');
        }
        if ($('#mtu-selectedPastComp li').length > 0) {
            queryParams += setFIlterQueryParams('#mtu-selectedPastComp', 'pastcompid', 'pastCompany');
        }
        if ($('#mtu-selectedIndustry li').length > 0) {
            queryParams += setFIlterQueryParams('#mtu-selectedIndustry', 'industryid', 'industry');
        }
        if ($('#mtu-selectedLanguage li').length > 0) {
            queryParams += setFIlterQueryParams('#mtu-selectedLanguage', 'langcode', 'profileLanguage');
        }

        // Add free text filters
        if ($('#mtu-firstName').val()) {
            queryParams += setFIlterQueryParamsFreeText('#mtu-firstName', 'firstName');
        }
        if ($('#mtu-lastName').val()) {
            queryParams += setFIlterQueryParamsFreeText('#mtu-lastName', 'lastName');
        }
        if ($('#mtu-school').val()) {
            queryParams += setFIlterQueryParamsFreeText('#mtu-school', 'schoolFreetext');
        }
        if ($('#mtu-title').val()) {
            queryParams += setFIlterQueryParamsFreeText('#mtu-title', 'title');
        }
        if ($('#mtu-company').val()) {
            queryParams += setFIlterQueryParamsFreeText('#mtu-company', 'company');
        }

        // Set minimum total and default start position
        const processedValues = {
            total: Math.max(parseInt(form.total.val()), 10),
            startPosition: parseInt(form.startPosition.val()) || 0,
            delay: parseInt(form.delay.val()),
            message: form.message.val()
        };

        console.log('📝 Processed values:', processedValues);

        // Show processing state
        $('.message-target-notice').show();
        $('#displayMessageTargetStatus').html(`
            <div class="alert alert-info">
                <i class="fas fa-spinner fa-spin"></i> Processing request...
            </div>
        `);

        // Process based on audience selection
        if (!form.audience.val()) {
            console.log('🔍 No audience selected, using PhantomBuster search...');
            
            // Get keywords (search term or fallback)
            const keywords = form.searchTerm.val() ? form.searchTerm.val().trim() : '';
            
            if (!keywords) {
                $('#mtu-error-notice').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> Please enter search keywords
                    </div>
                `);
                $('.messageTargetUserAction').attr('disabled', false);
                return;
            }
            
            // Map connection degrees - default to all if not specified
            // Check if there are connection degree checkboxes (similar to audience creation)
            const degreeMap = {
                'F': '1',
                'S': '2',
                'O': '3+'
            };
            let connectionDegrees = [];
            
            // Check for connection degree checkboxes (if they exist in UI)
            if ($('#mtu-connFirstCheck').length && $('#mtu-connFirstCheck').prop('checked')) {
                connectionDegrees.push('1');
            }
            if ($('#mtu-connSecondCheck').length && $('#mtu-connSecondCheck').prop('checked')) {
                connectionDegrees.push('2');
            }
            if ($('#mtu-connThirdCheck').length && $('#mtu-connThirdCheck').prop('checked')) {
                connectionDegrees.push('3+');
            }
            
            // If no connection degrees selected, default to all (2nd and 3rd+)
            if (connectionDegrees.length === 0) {
                connectionDegrees = ['2', '3+'];
            }
            
            // Build LinkedIn search URL using reusable function
            const searchUrl = window.buildLinkedInSearchUrl ? 
                window.buildLinkedInSearchUrl(keywords, 'mtu-', ['S', 'O']) : '';
            
            await mtuGetConnections(
                searchUrl,
                keywords,
                connectionDegrees,
                processedValues.startPosition,
                processedValues.total,
                processedValues.delay,
                processedValues.message,
                mtuConnectionIds
            );
        } else {
            console.log('👥 Using selected audience:', form.audience.val());
            const audience = parseInt(form.audience.val());
            await mtuGetAudienceData(
                processedValues.message,
                processedValues.delay,
                audience
            );
        }

    } catch (error) {
        console.error('❌ Error in send button handler:', error);
        $('#mtu-error-notice').html(`
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> Error: ${error.message}
            </div>
        `);
        $('.messageTargetUserAction').attr('disabled', false);
    }
});

const mtuGetConnections = async (searchUrl, keywords, connectionDegrees, mtuStartP, mtuTotal, mtuDelay, mtuMessage, mtuConnectionIds) => {
    $('.message-target-notice').show()
    $('#displayMessageTargetStatus').empty()
    $('#displayMessageTargetStatus').html('Scanning. Please wait...')
    let messageItems = [], totalResultCount = 0;

    let getConnectionsLooper = async () => {
        try {
            // Use PhantomBuster instead of Voyager API
            const response = await window.fetchPhantomSearchResults({
                searchUrl: searchUrl || null,
                keywords: keywords,
                connectionDegrees: connectionDegrees,
                limit: mtuTotal,
                startPosition: mtuStartP
            });

            // Response format: { data: { elements: [...], included: [...] }, included: [...] }
            let elements = response.data?.elements || response.elements || [];
            let included = response.included || [];

            // Find the element that contains the search results
            let searchResultElement = null;
            for(let i = 0; i < elements.length; i++) {
                if(elements[i] && elements[i].items && elements[i].items.length > 0) {
                    searchResultElement = elements[i];
                    break;
                }
            }

            if(searchResultElement && searchResultElement.items && searchResultElement.items.length > 0) {
                // Add items from elements
                for(let item of searchResultElement.items) {
                    messageItems.push(item);
                }

                // Also add items from included array
                for(let item of included) {
                    if(item.title && item.title.text && !item.title.text.includes('LinkedIn Member')) {
                        // Check if already added (avoid duplicates)
                        const alreadyAdded = messageItems.some(m => 
                            m.trackingId === item.trackingId || 
                            m.navigationUrl === item.navigationUrl
                        );
                        if(!alreadyAdded) {
                            messageItems.push(item);
                        }
                    }
                }

                if(totalResultCount == 0) {
                    totalResultCount = response.data?.metadata?.totalResultCount || messageItems.length;
                }

                if(messageItems.length < mtuTotal) {
                    // Continue pagination
                    mtuStartP = parseInt(mtuStartP) + messageItems.length;
                    $('#mtu-startPosition').val(mtuStartP);
                    setTimeout(() => {
                        getConnectionsLooper();
                    }, 10000);
                } else {
                    // Got enough results
                    mtuCleanConnectionsData(messageItems, totalResultCount, mtuDelay, mtuMessage, mtuConnectionIds);
                }
            } else if(messageItems.length > 0) {
                // No more results but we have some
                $('#displayMessageTargetStatus').html(`Found ${messageItems.length}. Messaging...`);
                mtuCleanConnectionsData(messageItems, totalResultCount, mtuDelay, mtuMessage, mtuConnectionIds);
            } else {
                // No results found
                $('#displayMessageTargetStatus').html('No result found, change your search criteria and try again!');
                $('.messageTargetUserAction').attr('disabled', false);
            }
        } catch(error) {
            console.error('Error fetching connections:', error);
            
            // Check for session expired error
            if (window.displaySessionExpiredError && window.displaySessionExpiredError(error, '#displayMessageTargetStatus')) {
                // Error message already displayed
            } else {
                $('#displayMessageTargetStatus').html(`Error: ${error.message || 'Something went wrong while trying to get connections!'}`);
            }
            
            $('.messageTargetUserAction').attr('disabled', false);
        }
    }
    
    getConnectionsLooper();
}

const mtuCleanConnectionsData = (messageItems, totalResultCount, mtuDelay, mtuMessage, mtuConnectionIds) => {
    try {
        console.log('🔍 Cleaning connections data...');
        let conArr = [], totalMessage = [];
        let newConArr, profileUrn;
        
        // Initialize storage if not exists
        let getMtuStore = localStorage.getItem('lkm-mtu');
        if (!getMtuStore) {
            getMtuStore = {
                position: 0,
                delay: 30,
                total: 10,
                uploads: []
            };
            localStorage.setItem('lkm-mtu', JSON.stringify(getMtuStore));
        } else {
            getMtuStore = JSON.parse(getMtuStore);
        }

        // Update store params
        if ($('#mtu-startPosition').val()) {
            getMtuStore.position = parseInt($('#mtu-startPosition').val());
        }
        if ($('#mtu-totalMessageConnect').val()) {
            getMtuStore.total = parseInt($('#mtu-totalMessageConnect').val());
        }
        if ($('#mtu-delayTime').val()) {
            getMtuStore.delay = parseInt($('#mtu-delayTime').val());
        }
        localStorage.setItem('lkm-mtu', JSON.stringify(getMtuStore));

        for (let item of messageItems) {
            let publicIdentifier = null;
            let fullName = '';
            let firstName = '';
            let lastName = '';
            let netDistance = 2; // Default to 2nd degree
            
            // Extract name from PhantomBuster/LinkedIn API format
            if (item.title && item.title.text) {
                fullName = item.title.text.trim();
                // Try to split name into first and last
                const nameParts = fullName.split(' ');
                firstName = nameParts[0] || '';
                lastName = nameParts.slice(1).join(' ') || '';
            }
            
            // Extract connection distance from PhantomBuster data
            if (item.entityCustomTrackingInfo && item.entityCustomTrackingInfo.memberDistance) {
                const distanceStr = item.entityCustomTrackingInfo.memberDistance;
                if (distanceStr.includes('DISTANCE_1') || distanceStr === '1') {
                    netDistance = 1;
                } else if (distanceStr.includes('DISTANCE_2') || distanceStr === '2') {
                    netDistance = 2;
                } else {
                    netDistance = 3;
                }
            }
            
            // Handle PhantomBuster/LinkedIn API format (new format)
            if (item.entityUrn) {
                // Extract from entityUrn: "urn:li:fsd_entityResultViewModel:(urn:li:fsd_profile:username,SEARCH_SRP,DEFAULT)"
                const match = item.entityUrn.match(/urn:li:fsd_profile:([^,]+)/);
                if (match && match[1]) {
                    publicIdentifier = match[1];
                }
            } 
            
            if (!publicIdentifier && item.navigationUrl) {
                // Extract from navigationUrl: "https://www.linkedin.com/in/username"
                const match = item.navigationUrl.match(/\/in\/([^\/\?]+)/);
                if (match && match[1]) {
                    publicIdentifier = match[1];
                }
            } 
            
            if (!publicIdentifier && item.trackingUrn) {
                // Extract from trackingUrn: "urn:li:member:username"
                const match = item.trackingUrn.match(/urn:li:member:(.+)/);
                if (match && match[1]) {
                    publicIdentifier = match[1];
                }
            }
            
            // Handle old Voyager API format (legacy format)
            if (!publicIdentifier && item.itemUnion && item.itemUnion['*entityResult']) {
                profileUrn = item.itemUnion['*entityResult'];
                if (profileUrn && profileUrn.includes('urn:li:fsd_entityResultViewModel:(urn:li:fsd_profile:') && 
                    profileUrn.includes(',SEARCH_SRP,DEFAULT)')) {
                    profileUrn = profileUrn.replace('urn:li:fsd_entityResultViewModel:(urn:li:fsd_profile:', '');
                    profileUrn = profileUrn.replace(',SEARCH_SRP,DEFAULT)', '');
                    publicIdentifier = profileUrn;
                }
            }

            if (publicIdentifier) {
                conArr.push({
                    conId: publicIdentifier,
                    name: fullName || `${firstName} ${lastName}`.trim() || 'LinkedIn Member',
                    firstName: firstName,
                    lastName: lastName,
                    netDistance: netDistance,
                    totalResultCount: totalResultCount,
                    // Include additional data for reference
                    navigationUrl: item.navigationUrl || null,
                    trackingUrn: item.trackingUrn || null,
                    title: item.primarySubtitle?.text || null
                });
            } else {
                console.warn('⚠️ Could not extract public identifier from item:', item);
            }
        }

        // Exclude connection if connectid exist in mtuConnectionIds
        if (mtuConnectionIds.length > 0) {
            const namesToDeleteSet = new Set(mtuConnectionIds);
            newConArr = conArr.filter((conArr) => {
                return !namesToDeleteSet.has(conArr.conId);
            });
        } else {
            newConArr = conArr;
        }

        // Get only user defined total
        for (let z = 0; z < newConArr.length; z++) {
            if (z < parseInt($('#mtu-totalMessageConnect').val())) {
                totalMessage.push(newConArr[z]);
            } else {
                break;
            }
        }

        console.log(`✅ Found ${totalMessage.length} connections to message`);
        
        // Build profile info array with data we already have from PhantomBuster
        // No need to call deprecated Voyager API endpoints
        const profileInfos = totalMessage.map(conn => ({
            name: conn.name || `${conn.firstName} ${conn.lastName}`.trim() || 'LinkedIn Member',
            firstName: conn.firstName || '',
            lastName: conn.lastName || '',
            conId: conn.conId,
            netDistance: conn.netDistance || 2
        }));
        
        console.log('📋 Profile info prepared from PhantomBuster data:', profileInfos);
        // Call send message function directly with profile info
        mtuSendMessageToConnection(mtuMessage, mtuDelay, profileInfos);

    } catch (error) {
        console.error('❌ Error in mtuCleanConnectionsData:', error);
        $('#displayMessageTargetStatus').html(`
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> Error processing connections: ${error.message}
            </div>
        `);
        $('.messageTargetUserAction').attr('disabled', false);
    }
};

const mtuGetAudienceData = async (mtuMessage, mtuDelay, audience) => {
    try {
        console.log(`🔍 Fetching audience data for audience ID: ${audience}`);
        
        // Show loading state
        $('.message-target-notice').show();
        $('#displayMessageTargetStatus').html(`
            <div class="alert alert-info">
                <i class="fas fa-spinner fa-spin"></i> Loading audience connections...
            </div>
        `);

        const response = await $.ajax({
            method: 'get',
            url: `${filterApi}/audience/list?audienceId=${audience}&totalCount=${$('#mtu-totalMessageConnect').val()}`,
            beforeSend: function(request) {
                if (linkedinId) {
                    const currentLinkedInId = (typeof window.getLinkedInIdForApi === 'function' ? window.getLinkedInIdForApi() : (linkedinId || window.linkedinId || $('#me-publicIdentifier').val()));
                    if (!currentLinkedInId) {
                        console.error('❌ LinkedIn ID not available for API call');
                        return;
                    }
                    request.setRequestHeader('lk-id', currentLinkedInId);
                }
            }
        });

        console.log('📊 Audience API response:', response);

        if (!response || !response.audience) {
            console.log('❌ No audience data returned');
            $('#displayMessageTargetStatus').html(`
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> No audience data found
                </div>
            `);
            $('.messageTargetUserAction').attr('disabled', false);
            return;
        }

        const audienceData = response.audience;
        if (!audienceData || audienceData.length === 0) {
            console.log('❌ No connections in audience');
            $('#displayMessageTargetStatus').html(`
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> No connections found in this audience
                </div>
            `);
            $('.messageTargetUserAction').attr('disabled', false);
            return;
        }

        console.log(`📋 Processing ${audienceData.length} connections from audience`);

        const conArr = [];
        for (let i = 0; i < audienceData.length; i++) {
            const connection = audienceData[i];
            
            let netDistance = null;
            if (connection.con_distance != null) {
                netDistance = connection.con_distance.split("_");
            }

            let targetId = null;
            if (connection.con_member_urn && connection.con_member_urn.includes('urn:li:member:')) {
                targetId = connection.con_member_urn.replace('urn:li:member:', '');
            }

            // Only include connections (commented out distance filter for now)
            // if (netDistance && parseInt(netDistance[1]) == 1) {
                conArr.push({
                    name: `${connection.con_first_name} ${connection.con_last_name}`,
                    firstName: connection.con_first_name,
                    lastName: connection.con_last_name,
                    title: connection.con_job_title,
                    conId: connection.con_id,
                    totalResultCount: audienceData.length,
                    publicIdentifier: connection.con_public_identifier,
                    memberUrn: connection.con_member_urn,
                    networkDistance: netDistance ? parseInt(netDistance[1]) : 1,
                    trackingId: connection.con_tracking_id,
                    navigationUrl: `${LINKEDIN_URL}/in/${connection.con_public_identifier}`,
                    targetId: targetId ? parseInt(targetId) : null,
                    netDistance: netDistance ? parseInt(netDistance[1]) : 1,
                });
            // }
        }

        console.log(`✅ Prepared ${conArr.length} connections for messaging`);

        if (conArr.length > 0) {
            console.log('🚀 About to call mtuSendMessageToConnection with:', {
                message: mtuMessage,
                delay: mtuDelay,
                connections: conArr.length
            });
            await mtuSendMessageToConnection(mtuMessage, mtuDelay, conArr);
        } else {
            console.log('❌ No valid connections found');
            $('#displayMessageTargetStatus').html(`
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> No 1st degree connections found.<br>Messages can only be sent to first degree connections
                </div>
            `);
            $('.messageTargetUserAction').attr('disabled', false);
        }

    } catch (error) {
        console.error('❌ Error in mtuGetAudienceData:', error);
        
        let errorMessage = 'Failed to load audience data';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.responseText) {
            errorMessage = error.responseText;
        } else if (error.message) {
            errorMessage = error.message;
        }

        $('#displayMessageTargetStatus').html(`
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> Error: ${errorMessage}
            </div>
        `);
        $('.messageTargetUserAction').attr('disabled', false);
    }
};

// Removed mtuGetProfileInfo - functionality now integrated into mtuCleanConnectionsData
// Profile data is already extracted from PhantomBuster response, no need for Voyager API calls

// var timeOutMsgTargetUsers;
// const mtuSendMessage = async (mtuMessage, mtuDelay, totalMessage) => {
//     var displayLi = '', i = 0, x= 0, newMessage = '', displayAutomationRecord = '';
//     let getMtuStore = JSON.parse(localStorage.getItem('lkm-mtu'));

//     $('.message-target-notice').show()

//     // automation table data setup
//     displayAutomationRecord = `
//         <tr id="message-targeted-users-record">
//             <td>Message Targeted Users</td>
//             <td id="mtu-status">Running</td>
//             <td>${totalMessage.length}</td>
//             <td id="mtu-numbered">0/${totalMessage.length}</td>
//             <td id="mtu-bot-action" title="Stop automation"><i class="far fa-dot-circle fa-lg text-danger cursorr"></i></td>
//             <td id="mtu-remained-time">${remainedTime(mtuDelay,totalMessage.length)}</td>
//         </tr>
//     `;
//     $('#no-job').hide()
//     $('#automation-list').append(displayAutomationRecord)
    

//     var mtuLooper = () => {
//         timeOutMsgTargetUsers = setTimeout(async function(){
//             newMessage = changeMessageVariableNames(mtuMessage, totalMessage[i])

//             await $.ajax({
//                 method: 'post',
//                 beforeSend: function(request) {
//                     request.setRequestHeader('csrf-token', jsession);
//                     request.setRequestHeader('accept', accept);
//                     request.setRequestHeader('content-type', contentType);
//                     request.setRequestHeader('x-li-lang', xLiLang);
//                     request.setRequestHeader('x-li-page-instance', xLiPageInstance);
//                     request.setRequestHeader('x-li-track', JSON.stringify(xLiTrack));
//                     request.setRequestHeader('x-restli-protocol-version', xRestliProtocolVersion);
//                 },
//                 url: `${voyagerApi}/messaging/conversations?action=create`,
//                 data: JSON.stringify({ 
//                     conversationCreate: {
//                         eventCreate: {
//                             value: {
//                                 'com.linkedin.voyager.messaging.create.MessageCreate' : {
//                                     attachments: getMtuStore.uploads.length ? getMtuStore.uploads : [],
//                                     body: newMessage, // message
//                                 }
//                             }
//                         },
//                         recipients: [totalMessage[i].conId],
//                         subtype: totalMessage[i].netDistance == 1 ? "MEMBER_TO_MEMBER" : "INMAIL"
//                     }
//                 }),
//                 success: function(data){
//                     if(data.value.createdAt){
//                         let conversationUrnId = data.value.backendEventUrn.replace('urn:li:messagingMessage:','')

//                         sendDeliveryAcknowledgement(conversationUrnId)

//                         $('#displayMessageTargetStatus').empty()
//                         displayLi = `
//                             <li>Message sent to: <b>${totalMessage[i].name}</b></li>
//                             <li>Total message sent: <b>${x +1}</b></li>
//                         `;
//                         $('#displayMessageTargetStatus').append(displayLi)

//                         // update automation count done and time remained
//                         $('#mtu-numbered').text(`${x +1}/${totalMessage.length}`)
//                         $('#mtu-remained-time').text(`${remainedTime(mtuDelay, totalMessage.length - (x +1))}`)

//                         if($('#mtu-viewProfile').prop('checked') == true){
//                             // mtuViewProfile(totalMessage[i])
//                         }
//                         x++;

//                     }else{
//                         $('#displayMessageTargetStatus').empty()
//                         $('#displayMessageTargetStatus').html('Something went wrong. Please try again')
//                         $('.messageTargetUserAction').attr('disabled', false)
//                     }
//                 },
//                 error: function(error){
//                     console.log(error)
//                     let notice = '';
//                     let msg = '';

//                     if(error.responseJSON.status){
//                         if(error.responseJSON.message){
//                             notice = error.responseJSON.message
//                         }else{
//                             notice = error.responseJSON.code
//                         }
//                         msg = `Message not sent.
//                             <br/>Reason: ${notice} <br/>
//                             Message inbox might be locked or user is not a 1st degree connection.
//                         `;
//                     }else {
//                         msg = ''
//                     }
                    
//                     $('#displayMessageTargetStatus').empty()
//                     $('#displayMessageTargetStatus').html(msg)
//                     $('.messageTargetUserAction').attr('disabled', false)
//                 }
//             })
//             i++;
//             if(i < totalMessage.length)
//                 mtuLooper()
//             if(i >= totalMessage.length){
//                 $('.messageTargetUserAction').attr('disabled', false)

//                 let module = 'Message sent';
//                 sendStats(x, module)

//                 if($('#mtu-viewProfile').prop('checked') == true){
//                     let module = 'Profile viwed';
//                     sendStats(x, module)
//                 }

//                 // update automation status
//                 $('#mtu-status').text('Completed')
//                 setTimeout(function(){
//                     $('#message-targeted-users-record').remove()
//                 }, 5000)
//             }
//         }, mtuDelay*1000)
//     }
//     mtuLooper()
// }

const mtuSendMessageToConnection = async (mtuMessage, mtuDelay, totalMessage) => {
    try {
        console.log('🔍 Starting Message Targeted Users for', totalMessage.length, 'connections');
        console.log('🔍 mtuSendMessageToConnection called with:', {
            messageLength: mtuMessage?.length || 0,
            delay: mtuDelay,
            connectionsCount: totalMessage?.length || 0,
            firstConnection: totalMessage?.[0]?.name || 'N/A'
        });
        
        var displayLi = '';
        let x = 0;
        
        // Initialize storage if not exists
        // Note: uploads removed - browser automation does not support attachments
        let getMtuStore = localStorage.getItem('lkm-mtu');
        if (!getMtuStore) {
            getMtuStore = { uploads: [] }; // Keep for backward compatibility but not used
        } else {
            getMtuStore = JSON.parse(getMtuStore);
        }

        $('.message-target-notice').show();

        // automation table data setup
        const displayAutomationRecord = `
            <tr id="message-targeted-users-record" style="transition: all 0.3s ease; border-bottom: 1px solid #f0f0f0;">
                <td style="padding: 16px; vertical-align: middle;">
                                                <div style="display: flex; align-items: center;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-right: 12px; box-shadow: 0 2px 8px rgba(239, 68, 68, 0.2);">
                                                        <i class="fas fa-bullseye" style="color: white; font-size: 16px;"></i>
                                                    </div>
                        <div>
                            <div style="font-weight: 600; color: #333; font-size: 15px; margin-bottom: 2px;">Message Targeted Users</div>
                            <div style="font-size: 12px; color: #6c757d;">
                                <i class="fas fa-paper-plane me-1"></i>Messaging automation
                            </div>
                        </div>
                    </div>
                </td>
                <td style="padding: 16px; text-align: center; vertical-align: middle;">
                    <div id="mtu-status" style="display: inline-flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #28a745 0%, #218838 100%); padding: 8px 16px; border-radius: 20px; font-weight: 600; color: white; min-width: 100px;">
                        <i class="fas fa-play-circle me-2"></i>
                        <span>Running</span>
                    </div>
                </td>
                    <td style="padding: 16px; text-align: center; vertical-align: middle;">
                        <div style="display: inline-flex; align-items: center; justify-content: center; background: linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(220, 38, 38, 0.1) 100%); padding: 8px 16px; border-radius: 20px; font-weight: 600; color: #ef4444; min-width: 60px; border: 1px solid rgba(239, 68, 68, 0.2);">
                            <i class="fas fa-list-ol me-2"></i>
                            <span>${totalMessage.length}</span>
                        </div>
                    </td>
                    <td style="padding: 16px; text-align: center; vertical-align: middle;">
                        <div id="mtu-numbered" style="display: inline-flex; align-items: center; justify-content: center; background: linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(220, 38, 38, 0.1) 100%); padding: 8px 16px; border-radius: 20px; font-weight: 600; color: #ef4444; min-width: 80px; border: 1px solid rgba(239, 68, 68, 0.2);">
                            <i class="fas fa-tasks me-2"></i>
                            <span>0/${totalMessage.length}</span>
                        </div>
                    </td>
                    <td style="padding: 16px; text-align: center; vertical-align: middle;">
                        <div id="mtu-remained-time" style="display: inline-flex; align-items: center; justify-content: center; background: linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(220, 38, 38, 0.1) 100%); padding: 8px 16px; border-radius: 20px; font-weight: 500; color: #ef4444; min-width: 100px; border: 1px solid rgba(239, 68, 68, 0.2);">
                            <i class="fas fa-clock me-2"></i>
                            <span>${remainedTime(mtuDelay, totalMessage.length)}</span>
                        </div>
                    </td>
                <td style="padding: 16px; text-align: center; vertical-align: middle;">
                    <div id="mtu-bot-action" title="Stop automation" style="display: inline-flex; align-items: center; justify-content: center;">
                        <button class="btn btn-sm cursorr" style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; border: none; border-radius: 6px; padding: 8px 16px; transition: all 0.3s; box-shadow: 0 2px 4px rgba(0,0,0,0.2);">
                            <i class="fas fa-stop-circle me-1"></i>Stop
                        </button>
                    </div>
                </td>
            </tr>
        `;
        $('#no-job').hide();
        $('#automation-list').append(displayAutomationRecord);

        for (const [i, item] of totalMessage.entries()) {
            try {
                // Prepare message parameters with fallbacks
                // Note: Attachments removed - browser automation does not support attachments
                const params = {
                    message: mtuMessage || '',
                    name: item.name || `${item.firstName || ''} ${item.lastName || ''}`.trim(),
                    firstName: item.firstName || '',
                    lastName: item.lastName || '',
                    distance: item.netDistance || 2,
                    connectionId: item.conId
                    // attachement: getMtuStore?.uploads?.length ? getMtuStore.uploads : [] // DISABLED: Browser automation does not support attachments
                };

                console.log(`📧 Sending message to: ${params.name} (${i + 1}/${totalMessage.length})`);
                console.log('📤 Using browser automation (background tab) instead of deprecated API');

                // Check if sendMessageToConnection function exists
                if (typeof sendMessageToConnection !== 'function') {
                    throw new Error('sendMessageToConnection function is not available. Make sure universalAction.js is loaded.');
                }

                // Send message using browser automation via background script
                // This opens LinkedIn profile tabs in the background and automates message sending
                const result = await sendMessageToConnection(params);
                
                if (result.status === 'successful') {
                    console.log('✅ Message sent successfully to:', params.name);
                    displayLi = `
                        <li>✅ Message sent to: <b>${params.name}</b></li>
                        <li>Total sent: <b>${i + 1}</b></li>
                    `;
                    $('#displayMessageTargetStatus').html(displayLi);

                    // Update automation count and time remaining
                    $('#mtu-numbered').text(`${i + 1}/${totalMessage.length}`);
                    $('#mtu-remained-time').text(`${remainedTime(mtuDelay, totalMessage.length - (i + 1))}`);
                    x++;
                } else {
                    console.log('ℹ️ Message not sent to:', params.name, result.message);
                    $('#displayMessageTargetStatus').html(`
                        <li style="color: blue;">ℹ️ Message not sent to: <b>${params.name}</b></li>
                        <li style="color: blue;">Info: ${result.message}</li>
                        <li style="color: gray;">Continuing with next connection...</li>
                    `);
                }

                // Add delay between messages (except for the last one)
                if (i < totalMessage.length - 1) {
                    console.log(`⏱️ Waiting ${mtuDelay} seconds before next message...`);
                    await sleep(mtuDelay * 1000);
                }

            } catch (itemError) {
                console.error('❌ Error processing connection:', item.name, itemError);
                $('#displayMessageTargetStatus').html(`
                    <li style="color: red;">❌ Error with: <b>${item.name}</b></li>
                    <li>Error: ${itemError.message}</li>
                    <li>Continuing with next connection...</li>
                `);
                continue; // Continue with next connection
            }
        }

        // Enable button and update status
        $('.messageTargetUserAction').attr('disabled', false);
        $('#mtu-status').text('Completed');
        
        // Remove automation record after delay
        setTimeout(() => {
            $('#message-targeted-users-record').remove();
        }, 5000);

        // Send stats
        if (x > 0) {
            console.log('📊 Sending stats:', x, 'messages sent');
            sendStats(x, 'Message sent');
        }

    } catch (error) {
        console.error('❌ Fatal error in mtuSendMessageToConnection:', error);
        $('#displayMessageTargetStatus').html(`
            <li style="color: red;">❌ Fatal error: ${error.message}</li>
            <li>Please try again or check console for details</li>
        `);
        $('.messageTargetUserAction').attr('disabled', false);
        $('#mtu-status').text('Error');
    }
};

const mtuViewProfile = async (totalMessage) => {
    await $.ajax({
        method: 'post',
        beforeSend: function(request) {
            request.setRequestHeader('csrf-token', jsession);
            request.setRequestHeader('content-type', 'application/json');
        },
        url: `${LINKEDIN_URL}/li/track`,
        data: JSON.stringify([{
            eventBody: {
                entityView: {
                    targetId: totalMessage.targetId,
                    viewType: "profile-view",
                    viewerId: parseInt($('#me-plainId').val())
                },
                header: {
                    clientApplicationInstance: {
                        applicationUrn: "urn:li:application:(voyager-web,voyager-web)",
                        trackingId: [115, -68, -55, -67, 121, 34, 64, 122, -102, -63, 39, 86, 88, 27, 112, 104],
                        version: "1.10.1648"
                    },
                    pageInstance: {
                        pageUrn: "urn:li:page:d_flagship3_profile_view_base",
                        trackingId: totalMessage.trackingId
                    },
                    time: dInt
                },
                networkDistance: totalMessage.networkDistance,
                profileTrackingId: totalMessage.trackingId,
                requestHeader: {
                    interfaceLocale: "en_US",
                    pageKey: "d_flagship3_profile_view_base",
                    path: totalMessage.navigationUrl,
                    referer: LINKEDIN_URL,
                    trackingCode: "d_flagship3_feed"
                },
                vieweeMemberUrn: totalMessage.memberUrn,
                viewerPrivacySetting: "F",
            },
            eventInfo: {
                appId: "com.linkedin.flagship3.d_web",
                eventName: "ProfileViewEvent",
                topicName: "ProfileViewEvent"
            }
        }]),
        success: function(data){
            
        },
        error: function(error){
            console.log(error)
            $('.endorseConnectionAction').attr('disabled', false)
        }
    })
}

// stop automation 
$('body').on('click','#mtu-bot-action',function(){
    clearTimeout(timeOutMsgTargetUsers);
    $('#mtu-status').html('<i class="fas fa-stop-circle me-2"></i><span>Stopped</span>');
    $('#mtu-status').css('background', 'linear-gradient(135deg, #dc3545 0%, #c82333 100%)');
    $('.messageTargetUserAction').attr('disabled', false)
    setTimeout(function(){
        $('#message-targeted-users-record').remove()
    }, 5000)
})